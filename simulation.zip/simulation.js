let TOLERANCE = 0.1;
let MINIMUM = 5
let SCALE = 500;
let POPULATION = 2200;
let COUNTER = 0;
let TURNCOUNTER = 0;
let STATE = true;
let frozen=false;
let CREATED=0;

//The nodes of the network
//----------------------------------------------------------
/*
let gridx = [5,250,495,5,250,495,5,250,495]; //9 (0-8)
let gridy = [495,495,495,250,250,250,5,5,5]; //9 (0-8)

//links for the network
//----------------------------------------------------------
links = [
    [1,3],[0,4,2],[1,5],
    [0,4,6],[1,3,5,7],[2,4,8],
    [3,7],[6,4,8],[7,5]
];

//controls at network nodes
controls = [1,2,1,1,0,1,0,3,3];
*/

//decision matrix
//note that it isn't symmetrical because sometimes players did choose neither
//Nothing

//0 - Lights, 1 = Zebra, 2 = Signs, 3 = Nothing
//0th element in 2D matrix is the 1st node, 1st is the 2nd
//all data
decisionMatrix = DM[0];

//how many nodes in the network
let NODE_COUNT = gridx.length;

//use this to create agents
function agent(){
    //this.speed=0.5;
    this.speed=0.65;
    // this.speed=Math.random()-.35;
    // if(this.speed < 0.3){
    //     this.speed=0.3;
    // }
    this.r=5;
    this.traversals = new Array(199).fill(false);

    this.start = function(){
        //console.log("INITIALIZE!!");
        //this.currentNode=getInteger(0,109);//start node
        //this.finaldestinationNode=getInteger(0,109);//final destination node
        this.currentNode=returnOrigin();
        this.finaldestinationNode=returnDestination();
        while(this.currentNode == this.finaldestinationNode){
            //this.finaldestinationNode=getInteger(0,109);
            this.finaldestinationNode=returnDestination();
        }

        this.id=COUNTER;
        COUNTER++;
        //console.log(this.id);
        this.destinationNode=bestMove(this.currentNode,this.finaldestinationNode,links[this.currentNode]);//end node
        this.x=gridx[this.currentNode];//current location x
        this.y=gridy[this.currentNode];//current location y
        this.dx=gridx[this.destinationNode];//destination x
        this.dy=gridy[this.destinationNode];//destination y
        this.slope = (this.y - this.dy)/(this.x-this.dx);

        if(this.dy > this.y){
            this.bearingy=1;
        }else if(this.dy < this.y){
            this.bearingy=-1;
        }else{
            this.bearingy=0;
        }

        if(this.dx > this.x){
            this.bearingx=1;
        }else if(this.dx < this.x){
            this.bearingx=-1;
        }else{
            this.bearingx=0;
        }
        //console.log("from " + this.currentNode + " to " + this.destinationNode + " at slope " + this.slope);
    }

    //this.colour=trait;//cyclist or pedestrian
/*     
    */
    this.move = function(){
        //console.log(" Current: " + this.currentNode);
        //console.log(" Desination: " + this.destinationNode);
        if(Math.pow(this.dx-this.x,2) > TOLERANCE || Math.pow(this.dy-this.y,2) > TOLERANCE){
            if(this.slope==0){
                this.y = this.y;
                this.x = (this.x + this.speed*this.bearingx);
            }
            else if(this.slope == Infinity){
                this.y = this.y - this.speed;
                this.x = this.x;
            }
            else if(this.slope == -Infinity){
                this.y = this.y + this.speed
                this.x = this.x;
            }
            else{
                this.y = this.slope*(this.x+this.speed)+495;
                this.x = (this.y-446)/this.slope;
            }
        //this.x = this.x + getInteger(-10, 10);
        //this.y = this.y + getInteger(-10, 10);
        }
        //if you have reached a destination...
        else{
            this.currentNode=this.destinationNode;
            //framerate and speed seem to be causing misses at intersections periodically?
            if(this.currentNode == this.finaldestinationNode){
                //console.log("RE-INITIALIZE");
                //start over again
                //this.currentNode=getInteger(0,109);//start node
                this.currentNode=returnOrigin();
                //this.finaldestinationNode=getInteger(0,109);//final destination node
                this.finaldestinationNode=returnDestination();
                while(this.currentNode == this.finaldestinationNode){
                    //this.finaldestinationNode=getInteger(0,109);
                    this.finaldestinationNode=returnDestination();
                }
                this.traversals = new Array(199).fill(false);
                this.id=COUNTER;
                COUNTER++;
                //console.log(this.id);
            }
            //console.log(" Final: " + this.finaldestinationNode);
            //console.log(" Links: " + links[this.currentNode]);
            this.destinationNode = bestMove(this.currentNode,this.finaldestinationNode,links[this.currentNode]);
            //console.log(" Waypoint: " + this.destinationNode);
            
            this.x=gridx[this.currentNode];//current location x
            this.y=gridy[this.currentNode];//current location y
            this.dx=gridx[this.destinationNode];//destination x
            this.dy=gridy[this.destinationNode];//destination y
            this.slope = (this.y - this.dy)/(this.x-this.dx);

            if(this.dy > this.y){
                this.bearingy=1;
            }else if(this.dy < this.y){
                this.bearingy=-1;
            }else{
                this.bearingy=0;
            }
    
            if(this.dx > this.x){
                this.bearingx=1;
            }else if(this.dx < this.x){
                this.bearingx=-1;
            }else{
                this.bearingx=0;
            }
        }
    }
    this.display = function(){
        strokeWeight(1);
        stroke(200*this.speed,0,0);
        fill(200*this.speed,0,0);
        ellipse(this.x,this.y,2);
    };
}

let allAgents = [];

//instances of the agents


//potential moves of the agent at given position
//console.log(links[allAgents[0].currentNode]);

//Counts the elements in the link file
function countElementsinArray(links){
    let cnt = 0;
    for(let i=0;i<links.length;++i){
        for(let j=0;j<links[i].length;++j){
            cnt++;
        }
    }
    return cnt;
}

//console.log(3);
//console.log(links[3]);

function getInteger(min, max) {
    return Math.floor(Math.random()*(max - min + 1) ) + min;
}

//choose a move based on 
function bestMove(s,d,m){
    let candidateMoves = [];
    let current = distance(gridx[s],gridy[s],gridx[d],gridy[d]);
    //consider all neighbouring links
    for(let i=0;i<m.length;++i){
        //if the move gets you closer to the objective push to candidate moves list
        if(distance(gridx[d],gridy[d],gridx[m[i]],gridy[m[i]]) < current){
            candidateMoves.push(m[i]);
        }
    }

    //shuffle candidateMoves order to ensure that there is no bias in the selction of route
    candidateMoves=shuffle(candidateMoves);

    //these are all moves that could be chosen
    //in a square grid, there should only be at most two candidate moves
    //there should be at minimum one
    for(let i=0;i<candidateMoves.length;++i){
        if(candidateMoves.length==1){
            return candidateMoves[0];
        }
        else{
            if(Math.random() < decisionMatrix[controls[candidateMoves[0]]][controls[candidateMoves[1]]]){
                return candidateMoves[0];
            }
            else{
                return candidateMoves[1];                
            }
        }
    }
}

//returns distance between two points
function distance(x1,y1,x2,y2){
    let d=0;
    d=Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    return d;
}

//total number of lines - with overlaps
//console.log(links[0].length);

//function for making sense of the network
function renderNetwork(links){
    background(255,255,255);
    for(let i=0;i<links.length;++i){
        for(let j=0;j<links[i].length;++j){
            stroke(220,220,220);
            strokeWeight(1);
            line(gridx[i], gridy[i], gridx[links[i][j]], gridy[links[i][j]]);
        }
    }
}

function renderMovers(allAgents){
    for(i=0;i<allAgents.length;++i){
        allAgents[i].move();
    }
}
let button;
let button1;
let button2;
let button3;

function setup(){
    createCanvas(SCALE+150,SCALE-49);
    for(let i=0;i<POPULATION;++i){
        allAgents[i] = new agent();
        allAgents[i].start();
    }

    //make the button for sending data to console
    button = createButton('Send data to console');
    button.style('color', color(255,255,255));
    button.style('background-color', color(0,0,0));
    button.style('border-radius', '3px');
    button.style('border', '2px solid #000000');
    button.style('font-size', '10px');
    button.position(10, 470);

    //make the button to freeze sim
    button1 = createButton('Freeze simulation');
    button1.style('background-color', color(255,255,255));
    button1.style('border-radius', '3px');
    button1.style('border', '2px solid #000000');
    button1.style('font-size', '10px');
    button1.position(130, 470);

    //make the button to freeze sim
    button2 = createButton('Re-initialize data');
    button2.style('background-color', color(255,255,255));
    button2.style('border-radius', '3px');
    button2.style('border', '2px solid #000000');
    button2.style('font-size', '10px');
    button2.position(235, 470);

    //make the button to clear intersections
    button3 = createButton('Clear all intersections');
    button3.style('background-color', color(255,255,255));
    button3.style('border-radius', '3px');
    button3.style('border', '2px solid #000000');
    button3.style('font-size', '10px');
    button3.position(335, 470);
}

function writetoConsole() {
    for(i=0;i<datanodes.length;++i){
        if(datanodes[i].traffic > 0){
            console.log(datanodes[i].id + "," + datanodes[i].traffic + "," + TURNCOUNTER);
        }
    }
}

 function reInitialize(){
    TURNCOUNTER=0;
    for(i=0;i<datanodes.length;++i){
        datanodes[i].traffic=0;
        datanodes[i].alpha=0;
    }
}

function clearIntersections(){
    for(let j=0;j<controls.length;++j){
        controls[j]=3;
        stroke(0,0,0,0);
        drawIntersections(gridx[j],gridy[j],controls[j]);
    }
}

function freezeSim(){
    if(STATE==true){
        noLoop();
        STATE=false;
        frozen=true;
    }else{
        loop();
        STATE=true;
        frozen=false;
    }
}

function draw(){
    TURNCOUNTER++;
    if(TURNCOUNTER >= 10000){
        freezeSim();
    }
    frameRate(60);

    //mouse behaviours
    button.mousePressed(writetoConsole);
    button.mouseOver(hoversendButton);
    button.mouseOut(unhoversendButton);

    button1.mousePressed(freezeSim);
    button2.mousePressed(reInitialize);
    button3.mousePressed(clearIntersections);

    button1.mouseOver(hoverButton);
    button2.mouseOver(hoverButton);
    button3.mouseOver(hoverButton);

    button1.mouseOut(unhoverButton);
    button2.mouseOut(unhoverButton);
    button3.mouseOut(unhoverButton);

    //call the choice function
    renderNetwork(links);
    renderMovers(allAgents);

    for(let j=0;j<datanodes.length;++j){
        stroke(200,200,0,datanodes[j].alpha);
        strokeWeight(5);
        line(datanodes[j].x1,datanodes[j].y1,datanodes[j].x2,datanodes[j].y2);
    }

    //does not have to be done every tick (in fact, shouldn't be...)
    for(let i=0;i<POPULATION;++i){
        let current_link=-1;
        allAgents[i].display();
        for(let j=0;j<datanodes.length;++j){
            if(checkoccupied(datanodes[j].x1,datanodes[j].y1,datanodes[j].x2,datanodes[j].y2,allAgents[i].x,allAgents[i].y)==1 
                && allAgents[i].traversals[j]==false){
                //console.log(datanodes[j].id + " Traversed by " + allAgents[i].id);
                datanodes[j].traffic++;
                allAgents[i].traversals[j]=true;
                datanodes[j].alpha=datanodes[j].alpha+2;
            }
        }
    }
    for(let j=0;j<datanodes.length;++j){
        stroke(150,150,150);
        textSize(10);
        if(frozen==true){
            text(datanodes[j].traffic, (datanodes[j].x1+datanodes[j].x2)/2, (datanodes[j].y1+datanodes[j].y2)/2);
        }
    }
    for(let i=0;i<controls.length;++i){
        stroke(0,0,0,0);
        fill(0,0,0);
        textSize(10);
        //text(i, gridx[i]-3,gridy[i]+3);
    }
    if (mouseIsPressed) {
        stroke(0,0,0,0);
          ellipse(mouseX,mouseY,5,5);
    }
    for(i=0;i<gridx.length;++i){
        stroke(0,0,0,0);
        drawIntersections(gridx[i],gridy[i],controls[i]);
    }

    //legend
    fill(0,0,0);
    text("Lights",542,37);
    text("Zebra stripes",542,87);
    text("Signs",542,137);
    text("No control",542,186);

    textSize(8);
    text(decisionMatrix[0][0],542,270);text(decisionMatrix[0][1],562,270);text(decisionMatrix[0][2],582,270);text(decisionMatrix[0][3],602,270);
    text(decisionMatrix[1][0],542,290);text(decisionMatrix[1][1],562,290);text(decisionMatrix[1][2],582,290);text(decisionMatrix[1][3],602,290);
    text(decisionMatrix[2][0],542,310);text(decisionMatrix[2][1],562,310);text(decisionMatrix[2][2],582,310);text(decisionMatrix[2][3],602,310);
    text(decisionMatrix[3][0],542,330);text(decisionMatrix[3][1],562,330);text(decisionMatrix[3][2],582,330);text(decisionMatrix[3][3],602,330);

    drawIntersections(550,50,0);
    drawIntersections(550,100,1);
    drawIntersections(550,150,2);
    drawIntersections(550,200,3);

    drawminiIntersections(549,255,0);
    drawminiIntersections(569,255,1);
    drawminiIntersections(589,255,2);
    drawminiIntersections(609,255,3);

    drawminiIntersections(535,266,0);
    drawminiIntersections(535,286,1);
    drawminiIntersections(535,306,2);
    drawminiIntersections(535,326,3);
    
    triangle(520, 261, 520, 271, 524, 266);
    triangle(520, 280, 520, 290, 524, 285);
    triangle(520, 300, 520, 310, 524, 305);
    triangle(520, 320, 520, 330, 524, 325);

}

function mouseClicked(){
    for(i=0;i<gridx.length;i++){
        if(distance(gridx[i],gridy[i],mouseX,mouseY) <= 10){
            if(controls[i]==0){
                controls[i]=1;
            }else if(controls[i]==1){
                controls[i]=2;
            }else if(controls[i]==2){
                controls[i]=3;
            }else if(controls[i]==3){
                controls[i]=0;
            }
        }
    }
}

function checkoccupied(a,b,c,d,x,y){
    if(x > (a-1) && x < (c+1) && y > (b-1) && y < (b+1)){
        return(1);
    }
    else{
        return(0);
    }
}

function drawIntersections(x,y,c){
    if(c==0){
        fill(0,200,200);
    }else if(c==1){
        fill(255,0,0);
    }else if(c==2){
        fill(0,255,0);
    }else if(c==3){
        fill(150,150,150);
    }else if(c==4){
        fill(255,255,255);
    }

    ellipse(x-5,y-5,5);
    ellipse(x+5,y+5,5);
    ellipse(x+5,y-5,5);
    ellipse(x-5,y+5,5);
}

function drawminiIntersections(x,y,c){
    if(c==0){
        fill(0,200,200);
    }else if(c==1){
        fill(255,0,0);
    }else if(c==2){
        fill(0,255,0);
    }else if(c==3){
        fill(150,150,150);
    }

    ellipse(x-2,y-2,2.75);
    ellipse(x+2,y+2,2.75);
    ellipse(x+2,y-2,2.75);
    ellipse(x-2,y+2,2.75);
}


function hoverButton(){
    this.style('background-color', color(200,200,200));
}

function unhoverButton(){
    this.style('background-color', color(255,255,255));
}

function hoversendButton(){
    this.style('color', color(255,0,0));
}

function unhoversendButton(){
    this.style('color', color(255,255,255));
}

//https://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array
function shuffle(array){
    let currentIndex = array.length,  randomIndex;
    while (currentIndex != 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex], array[currentIndex]];
    }
    return array;
}

function returnOrigin(){

    let candidates = [37,38,39,40,41,42,
                    48,49,50,51,52,53,
                    59,60,61,62,63,64,
                    70,71,72,73,74,75,
                    81,82,83,84,85,86,
                    92,93,94,95,96,97,
                    103,104,105,106,107,108];
    /*
    let weights = [18,37.12,37,64,46,27,
                    25,21,21,46,69,143,
                    25,36,36.192,167,185,162,
                    37,30,30,208,116,116,
                    148,120,120,324,301,208,
                    124,201,201,97,18,18,
                    124,201,236,97,18,18];*/
    let weights = [10,10,10,10,10,10,
                    10,10,10,10,10,10,
                    10,10,10,10,10,10,
                    10,10,10,10,10,10,
                    10,10,10,10,10,10,
                    10,10,10,10,10,10,
                    10,10,10,10,10,10];

    let probabilities = [];
    let cum_probabilities = [];
    let done=-1;

    let sumWeights=0;
    for(let i=0;i<weights.length;++i){
        sumWeights=sumWeights+weights[i];
    }
    for(let i=0;i<weights.length;++i){
        probabilities[i]=weights[i]/sumWeights;
        cum_probabilities[i]=0;
    }
    for(let i=0;i<weights.length;++i){
        if(i > 0){
            cum_probabilities[i]=cum_probabilities[i-1]+probabilities[i];
        }
    }
    let rr = Math.random();
    for(let i=1;i<weights.length;++i){
        if(rr > cum_probabilities[i-1] && rr <= cum_probabilities[i]){
            done=candidates[i-1];
        }
    }
    if(done!=-1){
        return(done);
    }else{
        return(candidates[getInteger(0,41)]);
    }
}

function returnDestination(){
    let candidates = [];
    let weights = [];

    for(i=0;i<110;++i){
        candidates[i]=i;
        weights[i]=0;//minimum weight for all destinations
    }

    //empirical weights
    /*
    weights[37]=58;weights[38]=116;weights[39]=116;weights[40]=228;weights[41]=145;weights[42]=187;weights[43]=287;
    weights[48]=78;weights[49]=118;weights[50]=118;weights[51]=270;weights[52]=342;weights[53]=624;weights[54]=664;
    weights[59]=81;weights[60]=138;weights[61]=138;weights[62]=697;weights[63]=730;weights[64]=657;weights[65]=635;
    weights[70]=116;weights[71]=94;weights[72]=94;weights[73]=727;weights[74]=487;weights[75]=537;weights[76]=490;
    weights[81]=464;weights[82]=377;weights[83]=377;weights[84]=1015;weights[85]=992;weights[86]=802;weights[87]=635;
    weights[92]=488;weights[93]=729;weights[94]=729;weights[95]=404;weights[96]=158;weights[97]=208;weights[98]=344;
    weights[103]=488;weights[104]=729;weights[105]=839;weights[106]=404;weights[107]=158;weights[108]=208;weights[109]=200;
    */
    weights[37]=10;weights[38]=10;weights[39]=10;weights[40]=10;weights[41]=10;weights[42]=10;weights[43]=10;
    weights[48]=10;weights[49]=10;weights[50]=10;weights[51]=10;weights[52]=10;weights[53]=10;weights[54]=10;
    weights[59]=10;weights[60]=10;weights[61]=10;weights[62]=10;weights[63]=10;weights[64]=10;weights[65]=10;
    weights[70]=10;weights[71]=10;weights[72]=10;weights[73]=10;weights[74]=10;weights[75]=10;weights[76]=10;
    weights[81]=10;weights[82]=10;weights[83]=10;weights[84]=10;weights[85]=10;weights[86]=10;weights[87]=10;
    weights[92]=10;weights[93]=10;weights[94]=10;weights[95]=10;weights[96]=10;weights[97]=10;weights[98]=10;
    weights[103]=10;weights[104]=10;weights[105]=10;weights[106]=10;weights[107]=10;weights[108]=10;weights[109]=10;


    let probabilities = [];
    let cum_probabilities = [];

    let sumWeights=0;
    for(let i=0;i<weights.length;++i){
        sumWeights=sumWeights+weights[i];
    }
    for(let i=0;i<weights.length;++i){
        probabilities[i]=weights[i]/sumWeights;
        cum_probabilities[i]=0;
    }
    for(let i=0;i<weights.length;++i){
        if(i > 0){
        cum_probabilities[i]=cum_probabilities[i-1]+probabilities[i];
        }
    }
    let rr = Math.random();
    for(let i=1;i<weights.length;++i){
        if(rr > cum_probabilities[i-1] && rr <= cum_probabilities[i]){
            CREATED++;
            return(candidates[i-1]);
        }
    }
}
