<?php

//FIRST STEP IS TO MAKE SURE THAT THE USER PREVILIGES ARE APPROPRIATE

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//key to get script to work but constrained to game rather than other users
header('Access-Control-Allow-Origin: https://www.decisiongame.ca');
//header('Access-Control-Allow-Origin: *');

include 'connect.php';//was connect_CRON before??

//Post to the market
if(isset($_GET['thetablename']) && isset($_GET['move']))
{
     //Sanitize the GET's to prevent SQL injections and possible XSS attacks
    $tablename = strip_tags(mysqli_real_escape_string($conn,$_GET['thetablename']));
    $prefix = "T";
    $TABLE = $prefix.strval($tablename);
    $MOVE = strip_tags(mysqli_real_escape_string($conn,$_GET['move']));   
    $TIME=time();

    $sql = mysqli_query($conn, "INSERT INTO $TABLE (`ID`,`MOVE`) VALUES ('$TIME','$MOVE');");
    if($sql){
     
          //The query returned true - now do whatever you like here.
          echo 'Move recorded sussessfully';
          $UPDATED = 1;
    }else{
     
          //The query returned false - you might want to put some sort of error reporting here. Even logging the error to a text file is fine.
          echo 'Post unsuccessful';
          echo '<br>';
          echo("Error description: " . mysqli_error($conn));
          $UPDATED = 0;
    }
}
else
{
     echo 'Could not connect.  Data not posted';
     $UPDATED = 0;
}

?>