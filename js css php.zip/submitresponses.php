<?php

//FIRST STEP IS TO MAKE SURE THAT THE USER PREVILIGES ARE APPROPRIATE
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//key to get script to work but constrained to game rather than other users
header('Access-Control-Allow-Origin: https://www.decisiongame.ca');
//header('Access-Control-Allow-Origin: *');

include 'phpscripts/connect.php';//was connect_CRON before??

//Post to the market
if(isset($_GET['gender']) && isset($_GET['age']) && isset($_GET['movement']))
{
     //Sanitize the GET's to prevent SQL injections and possible XSS attacks
    $RESPONSE_gender = strip_tags(mysqli_real_escape_string($conn,$_GET['gender']));
    $RESPONSE_age = strip_tags(mysqli_real_escape_string($conn,$_GET['age']));
    $RESPONSE_movement = strip_tags(mysqli_real_escape_string($conn,$_GET['movement']));
    $RESPONSE_ID = 0;
    $TIME = time();

    $sql = mysqli_query($conn, "INSERT INTO RESPONSES (`ID`,`TIME`,`GENDER`,`AGE`,`MOVEMENT`) VALUES ('$RESPONSE_ID','$TIME','$RESPONSE_gender','$RESPONSE_age','$RESPONSE_movement');");
    if($sql){
     
          //The query returned true - now do whatever you like here.
          echo 'Recorded sussessfully';
          $UPDATED = 1;
    }else{
     
          //The query returned false - you might want to put some sort of error reporting here. Even logging the error to a text file is fine.
          echo 'Post to market was unsuccessful';
          echo '<br>';
          echo("Error description: " . mysqli_error($conn));
          $UPDATED = 0;
    }
}
else
{
     echo 'Could not connect.  Data not posted';
     $UPDATED = 0;
}

?>