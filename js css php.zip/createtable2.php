<?php

//FIRST STEP IS TO MAKE SURE THAT THE USER PREVILIGES ARE APPROPRIATE

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//key to get script to work but constrained to game rather than other users
header('Access-Control-Allow-Origin: https://www.decisiongame.ca');
//header('Access-Control-Allow-Origin: *');

include 'connect.php';//was connect_CRON before??

//cleaner function
function TI($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

$theresult = "Unknown error";

//use GET to gather the user input
if (isset($_GET) & !empty($_GET))
{
    $tablename = strip_tags(mysqli_real_escape_string($conn,TI($_GET['thetablename'])));
}
else
{
    $theresult = "Number not valid";
}

$prefix = "X";//this is how we know its a bike
//$tablename = 123;#get this from post
$TABLE = $prefix.strval($tablename);
//echo $TABLE;#this is the tablename

#------------------------------------------------------------
#create data
function create_table($conn,$thetablename)
{
    $sql = "CREATE TABLE $thetablename (
    ID int(20) NOT NULL,
    MOVE varchar(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1";
    if (mysqli_query($conn, $sql))
    {
        echo "Table created successfully";
    }
    else
    {
        echo "Error creating table: " . mysqli_error($conn);
    }
}

create_table($conn,$TABLE);

mysqli_close($conn);
?>