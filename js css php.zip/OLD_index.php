<?php

//FIRST STEP IS TO MAKE SURE THAT THE USER PREVILIGES ARE APPROPRIATE
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//key to get script to work but constrained to game rather than other users
header('Access-Control-Allow-Origin: https://www.decisiongame.ca');
//header('Access-Control-Allow-Origin: *');

include 'phpscripts/connect.php';//was connect_CRON before??

//Post to the market
if(isset($_POST['age']) && isset($_POST['gender']) && isset($_POST['ethnicity']) && isset($_POST['movement']) && isset($_POST['frequency']))
{
     //Sanitize the GET's to prevent SQL injections and possible XSS attacks
    $RESPONSE_age = strip_tags(mysqli_real_escape_string($conn,$_POST['age']));
    $RESPONSE_gender = strip_tags(mysqli_real_escape_string($conn,$_POST['gender']));
    $RESPONSE_ethnicity = strip_tags(mysqli_real_escape_string($conn,$_POST['ethnicity']));
    $RESPONSE_movement = strip_tags(mysqli_real_escape_string($conn,$_POST['movement']));
    $RESPONSE_frequency = strip_tags(mysqli_real_escape_string($conn,$_POST['frequency']));
    $RESPONSE_ID = uniqid();
    $TIME = time();

    $sql = mysqli_query($conn, "INSERT INTO RESPONSES (`ID`,`TIME`,`AGE`,`GENDER`,`ETHNICITY`,`MOVEMENT`,`FREQUENCY`) VALUES ('$RESPONSE_ID','$TIME','$RESPONSE_age','$RESPONSE_gender','$RESPONSE_ethnicity','$RESPONSE_movement','$RESPONSE_frequency');");
    if($sql){
     
          //The query returned true - now do whatever you like here.
          echo ' ';
          $UPDATED = 1;
    }else{
     
          //The query returned false - you might want to put some sort of error reporting here. Even logging the error to a text file is fine.
          echo ' ';
          echo '<br>';
          echo ' ';
          $UPDATED = 0;
    }
}
else
{
     echo ' ';
     $UPDATED = 0;
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Safe Route Choice Game</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
	<meta name="author" content="Yiannakoulias">
	<link rel="manifest" href="appmanifest.json">
	<link rel="apple-touch-icon" sizes="128x128" href="icons/icon-128.png">
	<link rel="apple-touch-icon" sizes="256x256" href="icons/icon-256.png">
	<link rel="apple-touch-icon" sizes="512x512" href="icons/icon-512.png">
	<link rel="icon" type="image/png" href="icons/icon-512.png">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div id="fb-root"></div>

	<noscript>
		<div id="notSupportedWrap">
			<h2 id="notSupportedTitle">This content requires JavaScript</h2>
			<p class="notSupportedMessage">JavaScript appears to be disabled. Please enable it to view this content.</p>
			<p class="notSupportedMessage">This game was built in Construct 3&mdash;an <a href="https://www.construct.net/en">online game maker</a>.</p>
		</div>
	</noscript>
	<script src="scripts/supportcheck.js"></script>
	<script src="scripts/offlineclient.js"></script>
	<script src="scripts/main.js"></script>
	<script src="scripts/register-sw.js"></script>
</body>
</html>