<?php

//FIRST STEP IS TO MAKE SURE THAT THE USER PREVILIGES ARE APPROPRIATE
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//key to get script to work but constrained to game rather than other users
header('Access-Control-Allow-Origin: https://www.decisiongame.ca');
//header('Access-Control-Allow-Origin: *');

include 'phpscripts/connect.php';//was connect_CRON before??

//Post to the market
if(isset($_POST['age']) && isset($_POST['gender']) && isset($_POST['ethnicity']) && isset($_POST['movement']) && isset($_POST['frequency']))
{
     //Sanitize the GET's to prevent SQL injections and possible XSS attacks
    $RESPONSE_age = strip_tags(mysqli_real_escape_string($conn,$_POST['age']));
    $RESPONSE_gender = strip_tags(mysqli_real_escape_string($conn,$_POST['gender']));
    $RESPONSE_ethnicity = strip_tags(mysqli_real_escape_string($conn,$_POST['ethnicity']));
    $RESPONSE_movement = strip_tags(mysqli_real_escape_string($conn,$_POST['movement']));
    $RESPONSE_frequency = strip_tags(mysqli_real_escape_string($conn,$_POST['frequency']));
    $RESPONSE_ID = uniqid();
    $TIME = time();

    $sql = mysqli_query($conn, "INSERT INTO RESPONSES (`ID`,`TIME`,`AGE`,`GENDER`,`ETHNICITY`,`MOVEMENT`,`FREQUENCY`) VALUES ('$RESPONSE_ID','$TIME','$RESPONSE_age','$RESPONSE_gender','$RESPONSE_ethnicity','$RESPONSE_movement','$RESPONSE_frequency');");
    if($sql){
     
          //The query returned true - now do whatever you like here.
          echo 'Recorded sussessfully';
          $UPDATED = 1;
    }else{
     
          //The query returned false - you might want to put some sort of error reporting here. Even logging the error to a text file is fine.
          echo 'Post to market was unsuccessful';
          echo '<br>';
          echo("Error description: " . mysqli_error($conn));
          $UPDATED = 0;
    }
}
else
{
     echo 'Could not connect.  Data not posted';
     $UPDATED = 0;
}

?>